# gestion de stock
 
